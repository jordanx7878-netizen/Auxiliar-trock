TRICK SENSI — pacote web para empacotador Android

Arquivos:
- index.html: app com login, abas Funções / Otimização / Conta, cards cinza e preto.
- admin.html: gerador local de usuário/senha com validade máxima de 30 dias.
- manifest.webmanifest e assets/: ícone/logo.

Como testar:
1. Abra index.html num navegador para ver a interface.
2. Abra admin.html no mesmo navegador e crie um usuário/senha.
3. Volte a index.html no mesmo navegador e entre com essas credenciais.
4. Para o Newly APK Builder, envie os arquivos do site conforme os campos oferecidos pelo serviço. Se ele exigir uma URL pública, publique primeiro estes arquivos num host estático.

Limitações importantes:
- O login/admin deste ZIP é uma demonstração local; não é autenticação segura para clientes em aparelhos diferentes.
- Os botões de funções apenas salvam o estado visual e NÃO injetam arquivos .so, não escrevem na pasta privada do Free Fire, não alteram memória e não contornam proteções/anti-cheat.
- O botão ABRIR JOGO oferece links da Play Store para Free Fire ou Free Fire MAX; o comportamento de abertura direta depende do Android e do app instalado.
- A marca/ícone são TRICK SENSI. Este projeto não usa a identidade visual do Twitch para disfarçar o aplicativo.
- Para licenças de clientes reais, use backend/autenticação e verificação de validade no servidor.

Atualização:
- A aba Funções agora inclui uma seleção de arquivo .so e importação para armazenamento local do navegador.
- Por segurança e limitações do navegador, esta versão web NÃO grava diretamente em Android/media. Para isso, é necessário um wrapper Android nativo que use o seletor de documentos/Storage Access Framework e permissões adequadas.
- Importar/copiar uma biblioteca não a injeta nem a ativa dentro do Free Fire.
